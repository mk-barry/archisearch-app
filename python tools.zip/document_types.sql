-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 26 mai 2026 à 09:59
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `archisearch`
--

-- --------------------------------------------------------

--
-- Structure de la table `document_types`
--

CREATE TABLE `document_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `validation_rules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`validation_rules`)),
  `max_size_kb` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_perishable` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `document_types`
--

INSERT INTO `document_types` (`id`, `code`, `label`, `validation_rules`, `max_size_kb`, `created_at`, `updated_at`, `is_perishable`) VALUES
(2, 'BACC', 'Bacc ou equivalent', '{\"keywords\":[\"baccalaur\\u00e9at\",\"dipl\\u00f4me\",\"session\",\"matricule\",\"jury\",\"bacca\",\"admis\",\"s\\u00e9rie\"],\"min_score\":2}', 5120, '2026-05-13 06:34:14', '2026-05-13 06:34:14', 0),
(3, 'BAC', 'Baccalaureat', '{\"keywords\":[\"Baccalaur\\u00e9at\",\"baccalaur\",\"r\\u00e9publique du\",\"session\",\"matricule\",\"mention\",\"s\\u00e9rie\",\"jury\",\"d\\u00e9lib\\u00e9ration\"],\"min_score\":3}', 5120, '2026-05-13 10:03:39', '2026-05-13 10:03:39', 0),
(4, 'BACCC', 'Baccc', '{\"keywords\":[\"bacca\",\"baccalaureat\",\"mention\",\"jury\",\"office\",\"matricule\",\"phyique\",\"chimie\"],\"forbidden_keywords\":[\"probatoire\",\"brevet\"],\"required_metadata\":[\"jury\",\"mention\",\"matricule\",\"nom\"],\"minimum_confidence\":4,\"expiry_patterns\":[\"\"],\"metadata_patterns\":{\"mention\":[\"(?:mention)\\\\s*[:\\\\-]?\\\\s*(Tr\\u00e8s Bien|Bien|Assez Bien|Passable)\"],\"jury\":[\"(?:jury)\\\\s*[:\\\\-]?\\\\s*([A-Z0-9\\\\-]+)\"]}}', 2048, '2026-05-25 11:09:28', '2026-05-25 11:09:28', 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `document_types`
--
ALTER TABLE `document_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `document_types_code_unique` (`code`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `document_types`
--
ALTER TABLE `document_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
