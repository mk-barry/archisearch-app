-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 26 mai 2026 à 09:59
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `archisearch`
--

-- --------------------------------------------------------

--
-- Structure de la table `documents`
--

CREATE TABLE `documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `document_type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `tracking_code` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `status` enum('submitted','pending','validated','rejected','error') NOT NULL DEFAULT 'pending',
  `processed_by` varchar(255) DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `extracted_text` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ocr_words` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ocr_words`)),
  `flags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`flags`)),
  `ocr_score` int(11) DEFAULT NULL,
  `semantic_score` double DEFAULT NULL,
  `name_match_score` double DEFAULT NULL,
  `is_valid` tinyint(1) NOT NULL DEFAULT 0,
  `is_flagged` tinyint(1) NOT NULL DEFAULT 0,
  `is_expired` tinyint(1) NOT NULL DEFAULT 0,
  `expiry_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `documents`
--

INSERT INTO `documents` (`id`, `document_type_id`, `event_id`, `identifier`, `tracking_code`, `title`, `file_path`, `file_type`, `file_size`, `category`, `status`, `processed_by`, `processed_at`, `rejection_reason`, `metadata`, `extracted_text`, `created_at`, `updated_at`, `ocr_words`, `flags`, `ocr_score`, `semantic_score`, `name_match_score`, `is_valid`, `is_flagged`, `is_expired`, `expiry_date`) VALUES
(5, 3, 4, '22B004', 'AS-GFDZIW3Q', '1779717250_test-baca.PNG', 'documents/Test T5/22B004/1779717231_test-baca.PNG', 'PNG', 271, 'Baccalaureat', 'pending', NULL, NULL, NULL, '{\"score_ocr\":5,\"mots_trouves\":[\"baccalaur\",\"session\",\"matricule\",\"mention\",\"jury\"],\"validated_at\":\"2026-05-25 13:54:10\"}', 'cmr inistee des rapuffiqneducamesour cffieednsbaccafauviatdncamenoun saix-suait.9ati baccalaureat del\'enseignementsecandaine n24838 vulesled vule proces-verbaldes deliberations dujuryn 411 sessionde juin2024 lediploedubacculaureadeienseigementsecondaire general srie/specialitc:mathematiquesphysique-chimie matricule 63621627023 estconeream. mbatswengueyepkowenbarry douala mention passable nete)1e15-05-2008 sgatre d tlalire pourenjouir avec lesdroits et prerogatives quiy sontatiaches. faira hiownde 29/11/2024 le minire d enri lemindre deteng ledirecter depoffice da laconla dac 10031 i 00165248', '2026-05-25 12:54:10', '2026-05-25 12:54:10', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL),
(6, 4, 5, '22B004', 'AS-UZF858MV', '1779717625_test-baca.PNG', 'documents/Test T6/22B004/1779717610_test-baca.PNG', 'PNG', 271, 'Baccc', 'pending', NULL, NULL, NULL, '{\"score_ocr\":7,\"mots_trouves\":[\"bacca\",\"baccalaureat\",\"mention\",\"jury\",\"office\",\"matricule\",\"chimie\"],\"validated_at\":\"2026-05-25 14:00:25\",\"analysis\":{\"document_valid\":false,\"document_score\":0,\"document_details\":[],\"name_match\":true,\"name_score\":1,\"metadata\":{\"matricule\":\"63621627023\",\"mention\":\"passable\",\"jury\":\"n\"},\"flags\":[],\"is_expired\":false,\"expiry_date\":null}}', 'cmr inistee des rapuffiqneducamesour cffieednsbaccafauviatdncamenoun saix-suait.9ati baccalaureat del\'enseignementsecandaine n24838 vulesled vule proces-verbaldes deliberations dujuryn 411 sessionde juin2024 lediploedubacculaureadeienseigementsecondaire general srie/specialitc:mathematiquesphysique-chimie matricule 63621627023 estconeream. mbatswengueyepkowenbarry douala mention passable nete)1e15-05-2008 sgatre d tlalire pourenjouir avec lesdroits et prerogatives quiy sontatiaches. faira hiownde 29/11/2024 le minire d enri lemindre deteng ledirecter depoffice da laconla dac 10031 i 00165248', '2026-05-25 13:00:25', '2026-05-25 13:53:00', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `documents_event_id_foreign` (`event_id`),
  ADD KEY `documents_tracking_code_index` (`tracking_code`),
  ADD KEY `documents_document_type_id_foreign` (`document_type_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_document_type_id_foreign` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `documents_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
